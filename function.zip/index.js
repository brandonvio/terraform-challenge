const AWS = require("aws-sdk");

// var credentials = new AWS.SharedIniFileCredentials({ profile: "terransible" });
// AWS.config.credentials = credentials;
AWS.config.update({ region: "us-west-2" });

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "OnicaProjects";

exports.getProject = async function(event) {
  try {
    const params = {
      Key: {
        ProjectId: parseInt(event.pathParameters.projectId)
      },
      TableName: TABLE_NAME
    };
    const result = await dynamo.get(params).promise();
    console.log(JSON.stringify(result));
    return buildReponse(result.Item, 200);
  } catch (error) {
    console.error(error);
    return buildReponse(error, 500);
  }
};

exports.getProjectList = async function(event) {
  try {
    const params = {
      TableName: TABLE_NAME
    };
    const result = await dynamo.scan(params).promise();

    // If there are no projects, seed the project.
    if (result.Items.length === 0) {
      await seedProjects();
    }

    console.log(JSON.stringify(result));
    return buildReponse(result.Items, 200);
  } catch (error) {
    console.error(error);
    return buildReponse(error, 500);
  }
};

function buildReponse(data, status) {
  var response = {
    statusCode: status,
    body: JSON.stringify(data),
    isBase64Encoded: false
  };
  return response;
}

async function seedProjects() {
  const items = [
    {
      ProjectId: 1,
      ProjectName: "Microsoft AWS Cloud Migration",
      ProjectDueDate: "2020-01-01T08:00:00.000Z"
    },
    {
      ProjectId: 2,
      ProjectName: "Ford AWS Cloud Migration",
      ProjectDueDate: "2020-02-01T08:00:00.000Z"
    },
    {
      ProjectId: 3,
      ProjectName: "Google AWS Cloud Migration",
      ProjectDueDate: "2020-03-01T08:00:00.000Z"
    },
    {
      ProjectId: 4,
      ProjectName: "GM AWS Cloud Migration",
      ProjectDueDate: "2020-04-01T08:00:00.000Z"
    },
    {
      ProjectId: 5,
      ProjectName: "CNN AWS Cloud Migration",
      ProjectDueDate: "2020-05-01T08:00:00.000Z"
    }
  ];

  const promises = [];
  items.forEach(item => {
    const params = {
      TableName: TABLE_NAME,
      Item: item
    };
    promises.push(dynamo.put(params).promise());
  });

  const result = await Promise.all(promises);

  console.log(result);

  return result;
}
